from collections import namedtuple

SponsorSegment = namedtuple("SponsorSegment", ("uuid", "start", "end"))
