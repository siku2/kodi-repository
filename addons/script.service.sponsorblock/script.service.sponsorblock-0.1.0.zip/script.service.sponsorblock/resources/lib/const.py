CONF_API_SERVER = "api_server"
CONF_USER_ID = "user_id"
CONF_SHOW_SKIPPED_DIALOG = "show_skipped_dialog"
CONF_SKIP_COUNT_TRACKING = "skip_count_tracking"

VAR_PLAYER_PAUSED = "Player.Paused"
VAR_PLAYER_SPEED = "Player.PlaySpeed"
